import { useState } from "react";
import { Sidebar } from "@/components/chat/sidebar";
import { ChatInterface } from "@/components/chat/chat-interface";
import { useChat } from "@/hooks/use-chat";

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { currentChat, createNewChat, loadChat } = useChat();

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onNewChat={createNewChat}
        onLoadChat={loadChat}
        currentChatId={currentChat?.id}
      />

      {/* Main Chat Interface */}
      <div className="flex-1 flex flex-col">
        <ChatInterface
          chat={currentChat}
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          onNewChat={createNewChat}
        />
      </div>
    </div>
  );
}
