import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Chat } from "@shared/schema";

export function useChat() {
  const [currentChat, setCurrentChat] = useState<Chat | null>(null);
  const queryClient = useQueryClient();

  const createNewChatMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/chats", {
        title: "New Chat",
        subject: "other"
      });
      return response.json();
    },
    onSuccess: (newChat) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      setCurrentChat(newChat);
    },
  });

  const createNewChat = async () => {
    const newChat = await createNewChatMutation.mutateAsync();
    return newChat;
  };

  const loadChat = (chat: Chat) => {
    setCurrentChat(chat);
  };

  return {
    currentChat,
    createNewChat,
    loadChat,
    isCreatingChat: createNewChatMutation.isPending,
  };
}
