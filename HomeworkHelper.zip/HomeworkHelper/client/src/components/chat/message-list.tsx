import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { Bot, User, ThumbsUp, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { Message } from "@shared/schema";

interface MessageListProps {
  chatId: number;
}

export function MessageList({ chatId }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { data, isLoading } = useQuery<{ chat: any; messages: Message[] }>({
    queryKey: ["/api/chats", chatId],
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [data?.messages]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex space-x-3 animate-pulse">
            <div className="w-8 h-8 bg-gray-200 rounded-full" />
            <div className="flex-1 max-w-3xl">
              <div className="bg-gray-200 rounded-2xl h-20" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  const messages = data?.messages || [];

  const formatTimestamp = (timestamp: string | Date) => {
    return new Date(timestamp).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case "mathematics": return "text-purple-600 bg-purple-100";
      case "science": return "text-green-600 bg-green-100";
      case "english": return "text-blue-600 bg-blue-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const renderStepByStepContent = (content: string) => {
    // Simple parsing for step-by-step content
    const lines = content.split('\n');
    const steps: string[] = [];
    let currentStep = '';
    
    for (const line of lines) {
      if (line.match(/^\d+\./)) {
        if (currentStep) steps.push(currentStep);
        currentStep = line;
      } else if (currentStep) {
        currentStep += '\n' + line;
      }
    }
    
    if (currentStep) steps.push(currentStep);
    
    if (steps.length > 0) {
      return (
        <div className="bg-gray-50 rounded-lg p-4 mb-3">
          <h4 className="font-medium text-neutral-800 mb-3">Step-by-step solution:</h4>
          <div className="space-y-3">
            {steps.map((step, index) => (
              <div key={index} className="flex items-start space-x-3">
                <span className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center text-xs font-medium flex-shrink-0">
                  {index + 1}
                </span>
                <p className="text-sm">{step.replace(/^\d+\.\s*/, '')}</p>
              </div>
            ))}
          </div>
        </div>
      );
    }
    
    return null;
  };

  return (
    <div className="space-y-6">
      {messages.map((message) => (
        <div key={message.id}>
          {message.role === "user" ? (
            /* User Message */
            <div className="flex justify-end">
              <div className="max-w-xs lg:max-w-2xl">
                <div className="bg-primary text-white rounded-2xl rounded-br-md px-4 py-3">
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                <div className="flex items-center justify-end space-x-2 mt-1">
                  <span className="text-xs text-neutral-600">You</span>
                  <span className="text-xs text-neutral-600">
                    {formatTimestamp(message.createdAt)}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            /* Assistant Message */
            <div className="flex space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="text-white text-sm" />
              </div>
              <div className="flex-1 max-w-3xl">
                <div className="bg-white rounded-2xl rounded-bl-md px-4 py-3 border border-gray-200">
                  <div className="flex items-center space-x-2 mb-2">
                    {message.metadata && typeof message.metadata === 'object' && 'subject' in message.metadata && (
                      <span className={cn(
                        "text-xs font-medium px-2 py-1 rounded",
                        getSubjectColor(message.metadata.subject as string)
                      )}>
                        {(message.metadata.subject as string).charAt(0).toUpperCase() + 
                         (message.metadata.subject as string).slice(1)}
                      </span>
                    )}
                    <span className="text-xs text-neutral-600">GCSE Help Bot</span>
                  </div>
                  
                  <div className="prose prose-sm max-w-none">
                    {message.metadata && typeof message.metadata === 'object' && 'explanation_type' in message.metadata && message.metadata.explanation_type === 'step_by_step' ? (
                      <>
                        {renderStepByStepContent(message.content)}
                        <div className="whitespace-pre-wrap text-sm">
                          {message.content.split('\n').filter(line => !line.match(/^\d+\./)).join('\n')}
                        </div>
                      </>
                    ) : (
                      <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                    )}
                    
                    {/* Answer callout for math problems */}
                    {message.metadata && typeof message.metadata === 'object' && 'subject' in message.metadata && message.metadata.subject === 'mathematics' && (
                      message.content.toLowerCase().includes('answer') ||
                      message.content.includes('=')
                    ) && (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-3">
                        <div className="flex items-center space-x-2 mb-1">
                          <CheckCircle className="text-green-600 text-sm" />
                          <span className="font-medium text-green-600 text-sm">Answer</span>
                        </div>
                        <p className="text-sm text-neutral-800">Check your working above!</p>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-xs text-neutral-600">
                    {formatTimestamp(message.createdAt)}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs text-neutral-600 hover:text-green-600 h-auto p-1"
                  >
                    <ThumbsUp className="w-3 h-3 mr-1" />
                    <span>Helpful</span>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
      <div ref={messagesEndRef} />
    </div>
  );
}
