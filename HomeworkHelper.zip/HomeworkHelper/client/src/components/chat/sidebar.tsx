import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { Chat } from "@shared/schema";
import { 
  GraduationCap, 
  Calculator, 
  Atom, 
  Book, 
  LayersIcon, 
  Plus,
  X
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onLoadChat: (chat: Chat) => void;
  currentChatId?: number;
}

const subjectFilters = [
  { key: "all", label: "All Subjects", icon: LayersIcon, color: "text-primary" },
  { key: "mathematics", label: "Mathematics", icon: Calculator, color: "text-purple-600" },
  { key: "science", label: "Science", icon: Atom, color: "text-green-600" },
  { key: "english", label: "English", icon: Book, color: "text-blue-600" },
];

export function Sidebar({ isOpen, onClose, onNewChat, onLoadChat, currentChatId }: SidebarProps) {
  const [selectedSubject, setSelectedSubject] = useState("all");

  const { data: chats = [], isLoading } = useQuery<Chat[]>({
    queryKey: ["/api/chats"],
  });

  const filteredChats = chats.filter(chat => 
    selectedSubject === "all" || chat.subject === selectedSubject
  );

  const formatTimestamp = (timestamp: string | Date) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${Math.floor(diffInHours)} hours ago`;
    if (diffInHours < 48) return "1 day ago";
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case "mathematics": return "text-purple-600 bg-purple-50";
      case "science": return "text-green-600 bg-green-50";
      case "english": return "text-blue-600 bg-blue-50";
      default: return "text-gray-600 bg-gray-50";
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-80 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 lg:flex lg:flex-col",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex-1 flex flex-col min-h-0">
          {/* Header */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <GraduationCap className="text-white text-lg" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-neutral-800">GCSE Help Bot</h1>
                  <p className="text-sm text-neutral-600">AI Homework Assistant</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="lg:hidden"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Subject Filters */}
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-sm font-medium text-neutral-800 mb-3">Subjects</h3>
            <div className="space-y-2">
              {subjectFilters.map((filter) => {
                const Icon = filter.icon;
                const isSelected = selectedSubject === filter.key;
                
                return (
                  <Button
                    key={filter.key}
                    variant={isSelected ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start space-x-3 px-3 py-2",
                      isSelected 
                        ? "bg-primary text-white hover:bg-primary/90" 
                        : "text-neutral-600 hover:bg-gray-100"
                    )}
                    onClick={() => setSelectedSubject(filter.key)}
                  >
                    <Icon className="text-sm w-4 h-4" />
                    <span className="text-sm font-medium">{filter.label}</span>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Chat History */}
          <div className="flex-1 overflow-y-auto p-4">
            <h3 className="text-sm font-medium text-neutral-800 mb-3">Recent Chats</h3>
            {isLoading ? (
              <div className="space-y-2">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="p-3 rounded-lg border border-gray-200 animate-pulse">
                    <div className="h-4 bg-gray-200 rounded mb-2" />
                    <div className="h-3 bg-gray-200 rounded w-3/4" />
                  </div>
                ))}
              </div>
            ) : filteredChats.length > 0 ? (
              <div className="space-y-2">
                {filteredChats.map((chat) => (
                  <div
                    key={chat.id}
                    className={cn(
                      "p-3 rounded-lg border cursor-pointer transition-colors",
                      currentChatId === chat.id
                        ? "border-primary bg-blue-50"
                        : "border-gray-200 hover:bg-gray-50"
                    )}
                    onClick={() => onLoadChat(chat)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={cn(
                        "text-xs font-medium px-2 py-1 rounded",
                        getSubjectColor(chat.subject)
                      )}>
                        {chat.subject.charAt(0).toUpperCase() + chat.subject.slice(1)}
                      </span>
                      <span className="text-xs text-neutral-600">
                        {formatTimestamp(chat.updatedAt)}
                      </span>
                    </div>
                    <p className="text-sm text-neutral-800 line-clamp-2">
                      {chat.title}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-sm text-neutral-600">No chats found</p>
                <p className="text-xs text-neutral-500 mt-1">Start a new conversation!</p>
              </div>
            )}
          </div>

          {/* New Chat Button */}
          <div className="p-4 border-t border-gray-200">
            <Button
              onClick={onNewChat}
              className="w-full flex items-center justify-center space-x-2 px-4 py-3"
            >
              <Plus className="text-sm w-4 h-4" />
              <span className="font-medium">New Chat</span>
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
