import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useChat } from "@/hooks/use-chat";
import { apiRequest } from "@/lib/queryClient";
import { Paperclip, Send } from "lucide-react";

interface ChatInputProps {
  chatId?: number;
  onToggleFileUpload: () => void;
  showFileUpload: boolean;
}

export function ChatInput({ chatId, onToggleFileUpload, showFileUpload }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("auto-detect");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { createNewChat } = useChat();

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { chatId: number; message: string; file?: File }) => {
      const formData = new FormData();
      formData.append('content', data.message);
      formData.append('subject', selectedSubject === 'auto-detect' ? '' : selectedSubject);
      
      if (data.file) {
        formData.append('file', data.file);
      }

      const response = await fetch(`/api/chats/${data.chatId}/messages`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to send message');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      if (chatId) {
        queryClient.invalidateQueries({ queryKey: ["/api/chats", chatId] });
      }
      setMessage("");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) return;

    let currentChatId = chatId;
    
    // Create new chat if none exists
    if (!currentChatId) {
      const newChat = await createNewChat();
      currentChatId = newChat.id;
    }

    const fileInput = fileInputRef.current;
    const file = fileInput?.files?.[0];

    sendMessageMutation.mutate({
      chatId: currentChatId!,
      message: message.trim(),
      file
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const autoResizeTextarea = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const subjectOptions = [
    { key: "auto-detect", label: "Auto-detect" },
    { key: "mathematics", label: "Math" },
    { key: "science", label: "Science" },
    { key: "english", label: "English" },
  ];

  return (
    <div className="p-4 lg:p-6 bg-white border-t border-gray-200">
      <div className="max-w-4xl mx-auto">
        <form onSubmit={handleSubmit} className="flex items-end space-x-3">
          <div className="flex-1">
            <div className="relative">
              <Textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => {
                  setMessage(e.target.value);
                  autoResizeTextarea();
                }}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything about your GCSE homework..."
                className="w-full px-4 py-3 pr-12 bg-gray-50 border border-gray-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent min-h-[48px] max-h-32"
                rows={1}
                disabled={sendMessageMutation.isPending}
              />
              
              {/* File attachment button */}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleFileSelect}
                className="absolute right-3 bottom-3 p-1.5 text-neutral-600 hover:text-primary rounded-lg hover:bg-gray-100"
              >
                <Paperclip className="w-4 h-4" />
              </Button>
              
              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".pdf,.png,.jpg,.jpeg,.gif,.txt"
                multiple={false}
              />
            </div>
            
            {/* Subject selection */}
            <div className="flex items-center space-x-2 mt-2">
              <span className="text-xs text-neutral-600">Subject:</span>
              {subjectOptions.map((option) => (
                <Button
                  key={option.key}
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedSubject(option.key)}
                  className={`text-xs px-2 py-1 h-auto rounded hover:bg-gray-200 ${
                    selectedSubject === option.key
                      ? "bg-purple-100 text-purple-600"
                      : "bg-gray-100 text-neutral-600"
                  }`}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Send button */}
          <Button
            type="submit"
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="p-3 bg-primary text-white rounded-2xl hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {sendMessageMutation.isPending ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>
        
        {/* Disclaimer */}
        <p className="text-xs text-neutral-500 text-center mt-3">
          GCSE Help Bot can make mistakes. Please verify important information and use this as a learning aid.
        </p>
      </div>
    </div>
  );
}
