import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { X, Upload, FileText, Image, File } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  onClose: () => void;
  chatId?: number;
}

export function FileUpload({ onClose, chatId }: FileUploadProps) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileSelect = (file: File) => {
    // Validate file type
    const allowedTypes = ['application/pdf', 'text/plain', 'image/png', 'image/jpeg', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      alert('Unsupported file type. Please upload PDF, TXT, PNG, JPG, or GIF files.');
      return;
    }

    // Validate file size (10MB limit)
    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      alert('File size too large. Maximum size is 10MB.');
      return;
    }

    setSelectedFile(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) {
      return <Image className="w-6 h-6 text-blue-600" />;
    } else if (file.type === 'application/pdf') {
      return <FileText className="w-6 h-6 text-red-600" />;
    } else {
      return <File className="w-6 h-6 text-gray-600" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="p-4 lg:p-6 bg-blue-50 border-t border-blue-200">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl p-6 relative">
          {/* Close button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </Button>

          {!selectedFile ? (
            /* File Drop Zone */
            <div
              className={cn(
                "border-2 border-dashed rounded-xl p-8 text-center transition-colors",
                dragOver 
                  ? "border-primary bg-blue-50" 
                  : "border-blue-300 bg-white"
              )}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Upload className="text-primary text-xl" />
              </div>
              <h3 className="text-lg font-semibold text-neutral-800 mb-2">Upload Your Homework</h3>
              <p className="text-neutral-600 mb-4">Drop your files here or click to browse</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="mb-4"
              >
                Choose File
              </Button>
              <div className="flex flex-wrap justify-center gap-2 text-xs text-neutral-500">
                <span className="px-2 py-1 bg-gray-100 rounded">PDF</span>
                <span className="px-2 py-1 bg-gray-100 rounded">PNG</span>
                <span className="px-2 py-1 bg-gray-100 rounded">JPG</span>
                <span className="px-2 py-1 bg-gray-100 rounded">TXT</span>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".pdf,.png,.jpg,.jpeg,.gif,.txt"
                onChange={handleFileInputChange}
              />
            </div>
          ) : (
            /* Selected File Preview */
            <div className="text-center">
              <h3 className="text-lg font-semibold text-neutral-800 mb-4">File Selected</h3>
              <div className="flex items-center justify-center space-x-3 p-4 bg-gray-50 rounded-lg mb-4">
                {getFileIcon(selectedFile)}
                <div className="text-left">
                  <p className="font-medium text-neutral-800">{selectedFile.name}</p>
                  <p className="text-sm text-neutral-600">{formatFileSize(selectedFile.size)}</p>
                </div>
              </div>
              <div className="flex items-center justify-center space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setSelectedFile(null)}
                >
                  Change File
                </Button>
                <Button onClick={onClose}>
                  Continue with Upload
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
