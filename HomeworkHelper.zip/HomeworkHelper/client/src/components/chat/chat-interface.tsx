import { Button } from "@/components/ui/button";
import { MessageList } from "./message-list";
import { ChatInput } from "./chat-input";
import { FileUpload } from "./file-upload";
import { useState } from "react";
import type { Chat } from "@shared/schema";
import { 
  Menu, 
  Plus, 
  GraduationCap, 
  Calculator, 
  Atom, 
  Book,
  Bot
} from "lucide-react";

interface ChatInterfaceProps {
  chat: Chat | null;
  onToggleSidebar: () => void;
  onNewChat: () => void;
}

export function ChatInterface({ chat, onToggleSidebar, onNewChat }: ChatInterfaceProps) {
  const [showFileUpload, setShowFileUpload] = useState(false);

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-white border-b border-gray-200">
        <Button variant="ghost" size="icon" onClick={onToggleSidebar}>
          <Menu className="w-5 h-5 text-neutral-600" />
        </Button>
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <GraduationCap className="text-white text-sm" />
          </div>
          <h1 className="font-semibold text-neutral-800">GCSE Help Bot</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={onNewChat}>
          <Plus className="w-5 h-5 text-neutral-600" />
        </Button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 lg:p-6">
        <div className="max-w-4xl mx-auto">
          {!chat ? (
            /* Welcome Screen */
            <div className="text-center py-8 lg:py-12">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Bot className="text-white text-2xl" />
              </div>
              <h2 className="text-2xl lg:text-3xl font-bold text-neutral-800 mb-2">
                Welcome to GCSE Help Bot!
              </h2>
              <p className="text-neutral-600 text-lg mb-6">
                I'm here to help you with your Mathematics, Science, and English homework. Ask me anything!
              </p>
              
              {/* Quick Start Cards */}
              <div className="grid md:grid-cols-3 gap-4 max-w-3xl mx-auto">
                <div className="p-4 bg-white rounded-xl border border-gray-200 hover:border-purple-500 hover:bg-purple-50 transition-all group cursor-pointer">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-purple-200">
                    <Calculator className="text-purple-600 text-xl" />
                  </div>
                  <h3 className="font-medium text-neutral-800 mb-1">Mathematics</h3>
                  <p className="text-sm text-neutral-600">Algebra, geometry, statistics and more</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-gray-200 hover:border-green-500 hover:bg-green-50 transition-all group cursor-pointer">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-green-200">
                    <Atom className="text-green-600 text-xl" />
                  </div>
                  <h3 className="font-medium text-neutral-800 mb-1">Science</h3>
                  <p className="text-sm text-neutral-600">Biology, chemistry, physics concepts</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-all group cursor-pointer">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-blue-200">
                    <Book className="text-blue-600 text-xl" />
                  </div>
                  <h3 className="font-medium text-neutral-800 mb-1">English</h3>
                  <p className="text-sm text-neutral-600">Literature, writing, language skills</p>
                </div>
              </div>
            </div>
          ) : (
            <MessageList chatId={chat.id} />
          )}
        </div>
      </div>

      {/* File Upload Dropzone */}
      {showFileUpload && (
        <FileUpload 
          onClose={() => setShowFileUpload(false)}
          chatId={chat?.id}
        />
      )}

      {/* Chat Input */}
      <ChatInput
        chatId={chat?.id}
        onToggleFileUpload={() => setShowFileUpload(!showFileUpload)}
        showFileUpload={showFileUpload}
      />
    </>
  );
}
