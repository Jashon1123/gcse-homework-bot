# GCSE Homework Help Bot

## Overview

This is a full-stack web application that provides AI-powered homework assistance for GCSE students (UK high school level, ages 14-16). The application combines a React-based frontend with an Express.js backend, utilizing OpenAI's GPT-4 for educational support across multiple subjects including mathematics, science, and English.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI with shadcn/ui components for a polished interface
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **File Handling**: Multer for multipart/form-data uploads
- **Development**: Hot module replacement via Vite integration

### Data Storage Solutions
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Management**: Drizzle Kit for migrations
- **Storage Implementation**: In-memory storage fallback with interface for database operations
- **Session Storage**: PostgreSQL-based sessions using connect-pg-simple

## Key Components

### Chat System
- Real-time chat interface with message history
- Support for multiple concurrent chat sessions
- Subject-based chat categorization (mathematics, science, english, other)
- File upload capability for homework problems

### AI Integration
- OpenAI GPT-4o integration for educational responses
- Subject classification and response tailoring
- Image analysis for visual homework problems
- Step-by-step problem solving approach

### File Processing
- Multi-format file support (PDF, images, text files)
- Basic OCR simulation for image-to-text extraction
- File validation and size limits (10MB maximum)
- Base64 encoding for image processing

### UI Components
- Mobile-responsive design with collapsible sidebar
- Subject-based filtering and organization
- Toast notifications for user feedback
- Loading states and error handling

## Data Flow

1. **User Interaction**: Users create chats and send messages through the React frontend
2. **File Upload**: Files are processed server-side and converted to text or base64 as needed
3. **AI Processing**: Messages and files are sent to OpenAI for educational analysis
4. **Response Generation**: AI generates subject-appropriate, step-by-step educational responses
5. **Data Persistence**: Chat history and messages are stored in PostgreSQL
6. **Real-time Updates**: Frontend uses React Query for optimistic updates and cache management

## External Dependencies

### Core Technologies
- **OpenAI API**: GPT-4o model for educational content generation
- **Neon Database**: Serverless PostgreSQL hosting
- **Radix UI**: Accessible UI component primitives
- **TanStack Query**: Server state management and caching

### Development Tools
- **Vite**: Development server and build tool
- **Drizzle Kit**: Database schema management
- **ESBuild**: Production build optimization
- **TypeScript**: Type safety across the stack

## Deployment Strategy

### Development Environment
- Vite development server with HMR for frontend
- Express server with TypeScript compilation via tsx
- Automatic database migrations via Drizzle Kit
- File uploads stored locally in uploads directory

### Production Build
- Frontend built to static assets via Vite
- Backend bundled with ESBuild for Node.js deployment
- Static file serving integrated into Express server
- Database migrations applied via `db:push` command

### Configuration
- Environment-based configuration for database and API keys
- Replit-specific optimizations and error handling
- CORS and security middleware integration
- Session management with PostgreSQL backing

The application follows a modern full-stack architecture with clear separation between client and server concerns, utilizing TypeScript throughout for type safety and developer experience. The educational focus is maintained through specialized AI prompting and subject-aware response generation.