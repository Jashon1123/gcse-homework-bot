import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import { storage } from "./storage";
import { insertChatSchema, insertMessageSchema } from "@shared/schema";
import { generateHomeworkHelp, classifySubject, analyzeImage } from "./services/openai";
import { processUploadedFile, validateFile } from "./services/fileProcessor";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all chats
  app.get("/api/chats", async (req, res) => {
    try {
      const chats = await storage.getChats();
      res.json(chats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chats" });
    }
  });

  // Get specific chat with messages
  app.get("/api/chats/:id", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const chat = await storage.getChat(chatId);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }

      const messages = await storage.getMessagesByChat(chatId);
      res.json({ chat, messages });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat" });
    }
  });

  // Create new chat
  app.post("/api/chats", async (req, res) => {
    try {
      const parsed = insertChatSchema.parse(req.body);
      const chat = await storage.createChat(parsed);
      res.status(201).json(chat);
    } catch (error) {
      res.status(400).json({ message: "Invalid chat data" });
    }
  });

  // Send message and get AI response
  app.post("/api/chats/:id/messages", upload.single('file'), async (req: Request & { file?: Express.Multer.File }, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const { content, subject } = req.body;

      if (!content) {
        return res.status(400).json({ message: "Message content required" });
      }

      // Validate file if uploaded
      if (req.file) {
        const validation = validateFile(req.file);
        if (!validation.valid) {
          return res.status(400).json({ message: validation.error });
        }
      }

      // Create user message
      const userMessage = await storage.createMessage({
        chatId,
        role: "user",
        content,
        metadata: { subject }
      });

      // Process file if uploaded
      let fileData = null;
      let processedFile = null;
      
      if (req.file) {
        processedFile = await processUploadedFile(req.file.path, req.file.mimetype);
        
        fileData = await storage.createFile({
          messageId: userMessage.id,
          filename: req.file.filename,
          originalName: req.file.originalname,
          mimeType: req.file.mimetype,
          size: req.file.size,
          processedText: processedFile.extractedText
        });
      }

      // Generate AI response
      let messageForAI = content;
      if (processedFile?.extractedText) {
        messageForAI += `\n\nAttached file content: ${processedFile.extractedText}`;
      }

      const aiResponse = await generateHomeworkHelp(
        messageForAI,
        subject,
        processedFile?.base64Data
      );

      // Create assistant message
      const assistantMessage = await storage.createMessage({
        chatId,
        role: "assistant",
        content: aiResponse.content,
        metadata: { 
          subject: aiResponse.subject,
          explanation_type: aiResponse.explanation_type
        }
      });

      // Update chat title if it's the first message
      const chat = await storage.getChat(chatId);
      if (chat && chat.title === "New Chat") {
        const title = content.length > 50 ? content.substring(0, 47) + "..." : content;
        await storage.updateChat(chatId, { title, subject: aiResponse.subject });
      }

      res.json({
        userMessage,
        assistantMessage,
        file: fileData
      });

    } catch (error) {
      console.error("Message creation error:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Analyze image endpoint
  app.post("/api/analyze-image", upload.single('image'), async (req: Request & { file?: Express.Multer.File }, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const validation = validateFile(req.file);
      if (!validation.valid) {
        return res.status(400).json({ message: validation.error });
      }

      if (!req.file.mimetype.startsWith('image/')) {
        return res.status(400).json({ message: "File must be an image" });
      }

      const processedFile = await processUploadedFile(req.file.path, req.file.mimetype);
      
      if (!processedFile.base64Data) {
        return res.status(500).json({ message: "Failed to process image" });
      }

      const analysis = await analyzeImage(processedFile.base64Data);
      
      res.json({
        extractedText: processedFile.extractedText,
        analysis
      });

    } catch (error) {
      console.error("Image analysis error:", error);
      res.status(500).json({ message: "Failed to analyze image" });
    }
  });

  // Classify subject endpoint
  app.post("/api/classify-subject", async (req, res) => {
    try {
      const { text } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: "Text required for classification" });
      }

      const subject = await classifySubject(text);
      res.json({ subject });

    } catch (error) {
      console.error("Subject classification error:", error);
      res.status(500).json({ message: "Failed to classify subject" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
