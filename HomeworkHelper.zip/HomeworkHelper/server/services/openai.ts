import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "your_openai_api_key"
});

export interface ChatResponse {
  content: string;
  subject: string;
  explanation_type: 'step_by_step' | 'concept_explanation' | 'verification' | 'general';
}

export async function generateHomeworkHelp(
  message: string,
  subject?: string,
  imageBase64?: string
): Promise<ChatResponse> {
  try {
    const systemPrompt = `You are a GCSE homework help assistant for UK high school students. Your responses should be:

1. Educational and appropriate for GCSE level (ages 14-16)
2. Provide step-by-step explanations when solving problems
3. Include verification steps when possible
4. Use clear, encouraging language
5. Focus on teaching concepts, not just giving answers
6. Classify the subject as 'mathematics', 'science', 'english', or 'other'
7. Determine if this is a step_by_step problem, concept_explanation, verification, or general question

Respond in JSON format with:
{
  "content": "Your detailed educational response with step-by-step explanations",
  "subject": "mathematics|science|english|other",
  "explanation_type": "step_by_step|concept_explanation|verification|general"
}`;

    const messages: any[] = [
      { role: "system", content: systemPrompt }
    ];

    if (imageBase64) {
      messages.push({
        role: "user",
        content: [
          { type: "text", text: message },
          {
            type: "image_url",
            image_url: { url: `data:image/jpeg;base64,${imageBase64}` }
          }
        ]
      });
    } else {
      messages.push({ role: "user", content: message });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
      response_format: { type: "json_object" },
      max_tokens: 1500,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      content: result.content || "I'm sorry, I couldn't process your request. Please try again.",
      subject: result.subject || subject || 'other',
      explanation_type: result.explanation_type || 'general'
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate homework help response");
  }
}

export async function analyzeImage(base64Image: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this image and extract any text, mathematical equations, diagrams, or educational content. Focus on homework-related material suitable for GCSE level students."
            },
            {
              type: "image_url",
              image_url: { url: `data:image/jpeg;base64,${base64Image}` }
            }
          ]
        }
      ],
      max_tokens: 500,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Image analysis error:", error);
    throw new Error("Failed to analyze image");
  }
}

export async function classifySubject(text: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Classify this homework question into one of these GCSE subjects: mathematics, science, english, or other. Respond with only the subject name."
        },
        {
          role: "user",
          content: text
        }
      ],
      max_tokens: 10,
    });

    const subject = response.choices[0].message.content?.toLowerCase().trim();
    return ['mathematics', 'science', 'english'].includes(subject || '') ? subject! : 'other';
  } catch (error) {
    console.error("Subject classification error:", error);
    return 'other';
  }
}
