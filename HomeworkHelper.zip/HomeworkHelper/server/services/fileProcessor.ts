import fs from 'fs';
import path from 'path';

export interface ProcessedFile {
  extractedText: string;
  base64Data?: string;
  error?: string;
}

export async function processUploadedFile(filePath: string, mimeType: string): Promise<ProcessedFile> {
  try {
    if (mimeType.startsWith('image/')) {
      // For images, convert to base64 and extract text if possible
      const imageBuffer = await fs.promises.readFile(filePath);
      const base64Data = imageBuffer.toString('base64');
      
      // Simple OCR simulation - in a real app, you'd use Tesseract.js or similar
      return {
        extractedText: "Image uploaded - content will be analyzed by AI",
        base64Data
      };
    } else if (mimeType === 'text/plain') {
      // For text files, read content directly
      const textContent = await fs.promises.readFile(filePath, 'utf-8');
      return {
        extractedText: textContent
      };
    } else if (mimeType === 'application/pdf') {
      // For PDFs, simulate text extraction
      return {
        extractedText: "PDF uploaded - content will be analyzed by AI"
      };
    } else {
      return {
        extractedText: "",
        error: "Unsupported file type"
      };
    }
  } catch (error) {
    console.error("File processing error:", error);
    return {
      extractedText: "",
      error: "Failed to process file"
    };
  }
}

export function validateFile(file: Express.Multer.File): { valid: boolean; error?: string } {
  const maxSize = 10 * 1024 * 1024; // 10MB
  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'text/plain',
    'application/pdf'
  ];

  if (file.size > maxSize) {
    return { valid: false, error: "File size too large (max 10MB)" };
  }

  if (!allowedTypes.includes(file.mimetype)) {
    return { valid: false, error: "Unsupported file type" };
  }

  return { valid: true };
}
