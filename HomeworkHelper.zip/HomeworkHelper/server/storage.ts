import { chats, messages, files, type Chat, type Message, type File, type InsertChat, type InsertMessage, type InsertFile } from "@shared/schema";

export interface IStorage {
  // Chat operations
  getChats(): Promise<Chat[]>;
  getChat(id: number): Promise<Chat | undefined>;
  createChat(chat: InsertChat): Promise<Chat>;
  updateChat(id: number, updates: Partial<InsertChat>): Promise<Chat | undefined>;

  // Message operations
  getMessagesByChat(chatId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // File operations
  createFile(file: InsertFile): Promise<File>;
  getFilesByMessage(messageId: number): Promise<File[]>;
}

export class MemStorage implements IStorage {
  private chats: Map<number, Chat>;
  private messages: Map<number, Message>;
  private files: Map<number, File>;
  private currentChatId: number;
  private currentMessageId: number;
  private currentFileId: number;

  constructor() {
    this.chats = new Map();
    this.messages = new Map();
    this.files = new Map();
    this.currentChatId = 1;
    this.currentMessageId = 1;
    this.currentFileId = 1;
  }

  async getChats(): Promise<Chat[]> {
    return Array.from(this.chats.values()).sort((a, b) => 
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  async getChat(id: number): Promise<Chat | undefined> {
    return this.chats.get(id);
  }

  async createChat(insertChat: InsertChat): Promise<Chat> {
    const id = this.currentChatId++;
    const now = new Date();
    const chat: Chat = {
      ...insertChat,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.chats.set(id, chat);
    return chat;
  }

  async updateChat(id: number, updates: Partial<InsertChat>): Promise<Chat | undefined> {
    const chat = this.chats.get(id);
    if (!chat) return undefined;

    const updatedChat: Chat = {
      ...chat,
      ...updates,
      updatedAt: new Date(),
    };
    this.chats.set(id, updatedChat);
    return updatedChat;
  }

  async getMessagesByChat(chatId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.chatId === chatId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      createdAt: new Date(),
      metadata: insertMessage.metadata || null,
    };
    this.messages.set(id, message);
    
    // Update chat's updatedAt timestamp
    const chat = this.chats.get(insertMessage.chatId);
    if (chat) {
      this.chats.set(chat.id, { ...chat, updatedAt: new Date() });
    }
    
    return message;
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const id = this.currentFileId++;
    const file: File = {
      ...insertFile,
      id,
      createdAt: new Date(),
      processedText: insertFile.processedText || null,
    };
    this.files.set(id, file);
    return file;
  }

  async getFilesByMessage(messageId: number): Promise<File[]> {
    return Array.from(this.files.values())
      .filter(file => file.messageId === messageId);
  }
}

export const storage = new MemStorage();
