# GCSE Homework Help Bot

A comprehensive AI-powered homework assistance application designed specifically for UK GCSE students (ages 14-16). This web application provides educational support across mathematics, science, and English subjects with file upload capabilities and image recognition.

## Features

- **AI-Powered Responses**: Uses OpenAI GPT-4o for educational content generation
- **Subject-Specific Help**: Tailored responses for Mathematics, Science, and English
- **File Upload Support**: Process homework images, PDFs, and text files
- **Image Recognition**: OCR capabilities for handwritten or typed homework problems
- **Step-by-Step Solutions**: Detailed explanations for better learning
- **Chat History**: Organized conversation history by subject
- **Mobile Responsive**: Works seamlessly on desktop and mobile devices

## Tech Stack

**Frontend:**
- React with TypeScript
- Tailwind CSS + shadcn/ui components
- TanStack Query for state management
- Wouter for routing

**Backend:**
- Express.js with TypeScript
- Multer for file handling
- OpenAI API integration
- In-memory storage (easily upgradeable to PostgreSQL)

## Quick Start

### Prerequisites
- Node.js 20+
- OpenAI API key

### Installation

1. Clone the repository
```bash
git clone <your-repo-url>
cd gcse-homework-bot
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
# Add your OpenAI API key
OPENAI_API_KEY=sk-your-openai-api-key-here
```

4. Start the development server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Deployment

### Vercel (Recommended)
1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add `OPENAI_API_KEY` environment variable
4. Deploy

### Other Platforms
- **Netlify**: Supports full-stack applications
- **Railway**: Good for Node.js apps
- **Render**: Free tier available

## Usage

1. **Start a New Chat**: Click "New Chat" to begin
2. **Select Subject**: Choose from Mathematics, Science, English, or let AI auto-detect
3. **Ask Questions**: Type homework questions or upload files
4. **Get Help**: Receive step-by-step explanations and educational guidance

## File Support

- **Images**: PNG, JPG, GIF (for math problems, diagrams)
- **Documents**: PDF, TXT files
- **Size Limit**: 10MB per file

## Educational Approach

The bot is designed to:
- Provide step-by-step solutions rather than just answers
- Encourage learning through explanation
- Use age-appropriate language for GCSE level
- Focus on UK curriculum standards

## API Key Setup

Get your OpenAI API key:
1. Visit [platform.openai.com](https://platform.openai.com)
2. Create an account
3. Navigate to API Keys section
4. Create a new secret key
5. Add it to your environment variables

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - feel free to use this for educational purposes.

## Support

For issues or questions, please check the GitHub issues page or create a new issue.

---

Built with ❤️ for GCSE students across the UK.